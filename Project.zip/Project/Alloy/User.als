module User

sig User {}

