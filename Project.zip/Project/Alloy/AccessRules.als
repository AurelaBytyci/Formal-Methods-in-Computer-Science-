module AccessRules

open Admin
open User
open Email
open Consent

-- Admin accesses email with valid consent
pred accessWithConsent {
  some a: Admin, c: Consent |
    c.granted = True and
    c.email in a.canAccess
}

-- Admin accesses email without consent
pred accessWithoutConsent {
  some a: Admin, e: Email |
    e in a.canAccess and no c: Consent | c.email = e and c.granted = True
}

run accessWithConsent for 5
run accessWithoutConsent for 5
