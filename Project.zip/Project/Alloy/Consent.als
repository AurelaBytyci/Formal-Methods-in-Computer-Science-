module Consent

open User
open Email

sig Consent {
  user: one User,
  email: one Email,
  granted: one Bool
}

-- Simulate consent being granted
pred simulateConsentGranted {
  some c: Consent | c.granted = True
}

-- Simulate consent being revoked
pred simulateConsentRevoked {
  some c: Consent | c.granted = False
}

run simulateConsentGranted for 3
run simulateConsentRevoked for 3
