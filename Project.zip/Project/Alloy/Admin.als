module Admin

open Email

sig Admin {
  canAccess: set Email
}
