module Email

abstract sig Bool {}
one sig True, False extends Bool {}

sig Email {
  flagged: one Bool
}

-- Test if a flagged email exists
pred hasFlaggedEmail {
  some e: Email | e.flagged = True
}

run hasFlaggedEmail for 3
