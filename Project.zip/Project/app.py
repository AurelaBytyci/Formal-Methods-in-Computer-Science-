from flask import Flask, request, jsonify, render_template
import pyodbc
import re
from datetime import datetime, timedelta
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

app = Flask(__name__)
limiter = Limiter(key_func=get_remote_address)
limiter.init_app(app)

DB_CONFIG = {
    'server': 'localhost,1433',
    'database': 'ProjectDB',
    'username': 'sa',
    'password': 'YourStrongPassword123!',
    'driver': '{ODBC Driver 17 for SQL Server}'
}

def get_db_connection():
    conn = pyodbc.connect(
        f"DRIVER={DB_CONFIG['driver']};"
        f"SERVER={DB_CONFIG['server']};"
        f"DATABASE={DB_CONFIG['database']};"
        f"UID={DB_CONFIG['username']};"
        f"PWD={DB_CONFIG['password']};"
    )
    return conn

def is_valid_email(email):
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email)

def is_valid_admin(email, password):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT * FROM Admins WHERE AdminEmail = ? AND PasswordHash = ?",
            email, password
        )
        return cursor.fetchone() is not None
    except:
        return False
    finally:
        if 'conn' in locals():
            conn.close()

@app.route('/')
def index():
    return render_template('test_site.html')

@app.route('/grant_consent', methods=['POST'])
@limiter.limit("5 per minute")
def grant_consent():
    data = request.get_json()
    email = data.get('email')

    if not email or not is_valid_email(email):
        return jsonify({"error": "Invalid email address"}), 400

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Emails WHERE EmailAddress = ?", email)
        if cursor.fetchone():
            return jsonify({"error": f"Email {email} already exists."}), 400

        cursor.execute("INSERT INTO Emails (EmailAddress, Flagged, CreatedAt) VALUES (?, 0, ?)", email, datetime.now())
        cursor.execute("INSERT INTO Consent (email, ConsentGiven, CreatedAt) VALUES (?, 1, ?)", email, datetime.now())
        conn.commit()
        return jsonify({"message": f"Consent granted for {email}."})
    except Exception as e:
        return jsonify({"error": f"An error occurred: {e}"}), 500
    finally:
        if 'conn' in locals():
            conn.close()

@app.route('/revoke_consent', methods=['POST'])
@limiter.limit("5 per minute")
def revoke_consent():
    data = request.get_json()
    email = data.get('email')
    admin_email = data.get('adminEmail')
    admin_password = data.get('adminPassword')

    if not is_valid_admin(admin_email, admin_password):
        return jsonify({"error": "Invalid admin credentials"}), 403

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Consent WHERE email = ? AND ConsentGiven = 1", email)
        if not cursor.fetchone():
            return jsonify({"error": f"Email {email} is already revoked. No action taken."}), 400

        cursor.execute("UPDATE Consent SET ConsentGiven = 0 WHERE email = ?", email)
        conn.commit()
        return jsonify({"message": f"Consent revoked for {email}."})
    except Exception as e:
        return jsonify({"error": f"An error occurred: {e}"}), 500
    finally:
        if 'conn' in locals():
            conn.close()

@app.route('/flag_email', methods=['POST'])
@limiter.limit("5 per minute")
def flag_email():
    data = request.get_json()
    email = data.get('email')
    admin_email = data.get('adminEmail')
    admin_password = data.get('adminPassword')

    if not is_valid_admin(admin_email, admin_password):
        return jsonify({"error": "Invalid admin credentials"}), 403

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT Flagged FROM Emails WHERE EmailAddress = ?", email)
        row = cursor.fetchone()
        if not row:
            return jsonify({"error": f"Email {email} not found."}), 400

        flagged = row[0]
        if flagged == 1:
            return jsonify({
                "message": f"Email {email} is already flagged. No action taken.",
                "status": "no_change"
            }), 200

        cursor.execute("UPDATE Emails SET Flagged = 1 WHERE EmailAddress = ?", email)
        conn.commit()
        return jsonify({"message": f"Email {email} flagged successfully."}), 200
    except Exception as e:
        return jsonify({"error": f"An error occurred: {str(e)}"}), 500
    finally:
        if 'conn' in locals():
            conn.close()


@app.route('/unflag_email', methods=['POST'])
@limiter.limit("5 per minute")
def unflag_email():
    data = request.get_json()
    email = data.get('email')
    admin_email = data.get('adminEmail')
    admin_password = data.get('adminPassword')

    if not is_valid_admin(admin_email, admin_password):
        return jsonify({"error": "Invalid admin credentials"}), 403

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT Flagged FROM Emails WHERE EmailAddress = ?", email)
        row = cursor.fetchone()
        if not row:
            return jsonify({"error": f"Email {email} not found."}), 400

        flagged = row[0]
        if flagged == 0:
            return jsonify({
                "message": f"Email {email} is already unflagged. No action taken.",
                "status": "no_change"
            }), 200

        cursor.execute("UPDATE Emails SET Flagged = 0 WHERE EmailAddress = ?", email)
        conn.commit()
        return jsonify({"message": f"Email {email} unflagged successfully."}), 200
    except Exception as e:
        return jsonify({"error": f"An error occurred: {str(e)}"}), 500
    finally:
        if 'conn' in locals():
            conn.close()

@app.route('/cleanup_expired', methods=['POST'])
def cleanup_expired():
    threshold = datetime.now() - timedelta(days=30)
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            DELETE FROM Emails
            WHERE CreatedAt < ? AND Flagged = 0 AND EmailAddress IN (
                SELECT email FROM Consent WHERE ConsentGiven = 0
            )
        """, threshold)
        deleted = cursor.rowcount
        conn.commit()
        return jsonify({"message": f"Cleanup complete. {deleted} expired emails deleted."})
    except Exception as e:
        return jsonify({"error": f"An error occurred: {e}"}), 500
    finally:
        if 'conn' in locals():
            conn.close()

@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "The requested URL was not found on the server."}), 404

if __name__ == '__main__':
    app.run(debug=True)
