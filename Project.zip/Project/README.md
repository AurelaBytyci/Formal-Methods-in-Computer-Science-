# Email Consent Management System

## Project Overview
This project implements an Email Consent Management System designed to enhance data privacy and streamline consent management. The system offers features for granting and revoking consent, flagging/unflagging emails, admin controls, and automatic cleanup of outdated data. It emphasizes security, user-friendliness, and compliance with modern data protection standards.

## Behavior for Repeated Actions
The system is designed to handle repeated requests gracefully. If an admin or user tries to:

- Grant consent for an email that already has consent
- Revoke consent that is already revoked
- Flag an email that is already flagged
- Unflag an email that is already unflagged

## Features
- **Email Validation**: Ensures only valid email addresses are processed.
- **Consent Granting and Revocation**: Allows users to manage their consent status.
- **Email Flagging and Unflagging**: Admins can flag suspicious emails for review.
- **Rate Limiting**: Prevents abuse by limiting repeated actions within a specific time frame.
- **Admin Controls**: Secure admin operations for managing flagged emails and overseeing consent records.
- **Automatic Cleanup**: Deletes expired email records after 30 days.
- **Duplicate Action Detection**: If a user or admin attempts to repeat an action (e.g., flagging an already flagged email, revoking consent that's already revoked), the system detects it and returns a clear message such as "Email is already flagged. No action taken."

## Tools and Technologies
- **Programming**: Python, Flask
- **Database**: Microsoft SQL Server (via Docker), managed with DBeaver
- **Frontend**: HTML, CSS, JavaScript
- **API Testing**: Postman
- **Modeling and Verification**: Alloy Analyzer
- **IDE**: PyCharm

## Prerequisites
- Python 3.8 or higher
- Flask and other dependencies:
```bash
pip install flask flask-limiter pyodbc
```
- Docker (for running SQL Server)
- DBeaver (for managing the SQL database)

## Database Tables
- **Emails**: Stores email addresses and their status (flagged or not).
- **Consent**: Tracks consent status and timestamps for each email.
- **Admins**: Stores admin credentials (email, username, password, role).

## Installation Steps
1. Clone or download the project files into a local directory.
2. Open the project folder in PyCharm.
3. Run SQL Server in Docker and create the required tables (`Emails`, `Consent`, `Admins`).
4. Update the `DB_CONFIG` section in `app.py` with your Docker container's database credentials.
5. Run the Flask application:
```bash
python app.py
```
6. Access the application at:
```
http://127.0.0.1:5000
```

## Testing the System

### Grant Consent
**Endpoint:** `POST /grant_consent`  
**Request Body (JSON):**
```json
{ "email": "test@example.com" }
```
**Expected Response:**
```json
{ "message": "Consent granted for test@example.com." }
```

---

### Revoke Consent
**Endpoint:** `POST /revoke_consent`  
**Request Body (JSON):**
```json
{
  "email": "test@example.com",
  "adminEmail": "admin@example.com",
  "adminPassword": "admin123"
}
```
**Expected Response:**
```json
{ "message": "Consent revoked for test@example.com." }
```

> Note: Multiple admin users are supported. Their credentials are stored in the `Admins` table.

---

### Flag Email
**Endpoint:** `POST /flag_email`  
**Request Body (JSON):**
```json
{
  "email": "test@example.com",
  "adminEmail": "admin@example.com",
  "adminPassword": "admin123"
}
```

---

### Unflag Email
**Endpoint:** `POST /unflag_email`  
**Request Body (JSON):**
```json
{
  "email": "test@example.com",
  "adminEmail": "admin@example.com",
  "adminPassword": "admin123"
}
```

---

### Cleanup Expired Emails
**Endpoint:** `POST /cleanup_expired`  
**No Request Body Needed**  
**Expected Response:**
```json
{ "message": "Cleanup complete. (number) expired emails deleted." }
```

---

### Invalid Routes Test
**Endpoint:** `GET /invalid_route`  
**Expected Response:**
```json
{ "error": "The requested URL was not found on the server." }
```

### Running the Alloy Analyzer (Mac Users)
- To run the Alloy Analyzer on macOS, ensure you have Java 8 installed. Since Alloy is not compatible with newer Java versions, you'll need to execute it using Java 8 manually.
- Steps:
1. Download and install Java 8 (e.g., jdk1.8.0_202) from Oracle or AdoptOpenJDK.
2. Place the alloy4.jar file on your Desktop.
3. Launch Alloy via terminal using the following command:

```bash
/Library/Java/JavaVirtualMachines/jdk1.8.0_202.jdk/Contents/Home/bin/java -jar ~/Desktop/alloy4.jar
- This ensures Alloy runs with the correct Java version, avoiding compatibility issues.

## Known Issues
- Ensure that the database tables are properly created before running the application.
- Currently, password hashing is not implemented; passwords are stored as plain text.

## Future Work
- Add hashed password authentication for admins.
- Integrate AI-based email filtering for suspicious email detection.
- Develop a dashboard for admin analytics.
- Expand the system to support mobile platforms and role-based access control.
