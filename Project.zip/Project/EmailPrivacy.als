// Define the Boolean type using an enumeration
enum Bool { True, False }

// Define the main elements
sig User {
    email: lone Email,        // A user can have at most one email
    consentGiven: one Bool,   // Whether the user has given consent
    flagged: lone Email       // Emails explicitly flagged by the user
}

sig Email {
    age: Int                  // Age of the email in days
}

sig Admin {
    canAccess: set Email      // Emails an admin can access
}

// Define rules (facts)

// Consent Policy: If a user has given consent, they must have an email
fact ConsentPolicy {
    all u: User | u.consentGiven = True implies u.email != none
}

// Deletion Policy: If a user has not given consent, they must not have an email
fact DeletionPolicy {
    all u: User | u.consentGiven = False implies no u.email
}

// Data Retention Policy: Emails older than 30 days must be deleted unless flagged
fact DataRetentionPolicy {
    all e: Email | e.age < 30 or (some u: User | e = u.flagged)
}

// Access Control: Only Admins can access emails
fact AccessControl {
    all e: Email | some a: Admin | e in a.canAccess
}

// Email Duplication: Each email must belong to a unique user
fact UniqueEmail {
    all disj u1, u2: User | u1.email != u2.email
}

// Example Scenarios

// Simulate users giving consent
pred simulateConsent {
    some u: User | u.consentGiven = True
}

// Simulate users withdrawing consent
pred simulateRevokeConsent {
    some u: User | u.consentGiven = False and no u.email
}

// Simulate an admin accessing emails
pred simulateAdminAccess {
    some a: Admin, e: Email | e in a.canAccess
}

// Simulate flagged emails
pred simulateFlaggedEmails {
    some u: User | some e: Email | e = u.flagged
}

// Simulate a scenario where there are no admins
pred simulateNoAdmins {
    no Admin
}

// Assertions for testing

// Assert that no email exists without consent
assert NoEmailWithoutConsent {
    all u: User | u.consentGiven = False implies no u.email
}

// Assert that emails are unique across users
assert EmailIsUnique {
    all disj u1, u2: User | u1.email != u2.email
}

// Assert that emails older than 30 days are deleted unless flagged
assert RetentionPolicyHolds {
    all e: Email | e.age < 30 or (some u: User | e = u.flagged)
}

// Run checks and simulations

// Check the validity of assertions
check NoEmailWithoutConsent for 5 User, 5 Email, 3 Admin
check EmailIsUnique for 5 User, 5 Email, 3 Admin
check RetentionPolicyHolds for 5 User, 5 Email, 3 Admin

// Run scenarios to visualize
run simulateConsent for 5 User, 5 Email, 3 Admin
run simulateRevokeConsent for 5 User, 5 Email, 3 Admin
run simulateAdminAccess for 5 Admin, 5 Email, 5 User
run simulateFlaggedEmails for 5 User, 5 Email, 3 Admin
run simulateNoAdmins for 5 User, 5 Email, 0 Admin
